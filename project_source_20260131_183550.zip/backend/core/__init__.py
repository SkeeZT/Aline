# Core utilities and configuration
